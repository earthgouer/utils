package main

import (
	"crypto/rand"
	"database/sql"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"hash/crc32"
	"html/template"
	"net/http"
	"os"
	"strconv"
	"sync"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

var usedCaptchas sync.Map // 保存已用过的验证码

var db *sql.DB

type Config struct {
	DBUser     string `json:"db_user"`
	DBPassword string `json:"db_password"`
	DBHost     string `json:"db_host"`
	DBPort     int    `json:"db_port"`
	DBName     string `json:"db_name"`
	ServerPort int    `json:"server_port"`
	TableName  string `json:"table_name"`
	TypeFiled  string `json:"type_filed"`
	TypeValue  string `json:"type_value"`
	ValueFiled string `json:"value_filed"`
	CodeFiled  string `json:"code_filed"`
}

var config Config

func loadConfig() error {
	file, err := os.Open("config.json")
	if err != nil {
		return err
	}
	defer file.Close()
	return json.NewDecoder(file).Decode(&config)
}

func init() {
	if err := loadConfig(); err != nil {
		panic(fmt.Sprintf("读取配置文件失败: %v", err))
	}
	var err error
	connStr := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s",
		config.DBUser, config.DBPassword, config.DBHost, config.DBPort, config.DBName)

	// 连接MySQL数据库
	db, err = sql.Open("mysql", connStr)
	if err != nil {
		panic(fmt.Sprintf("数据库连接失败: %v", err))
	}

	// 测试连接
	if err = db.Ping(); err != nil {
		panic(fmt.Sprintf("数据库 ping 失败: %v", err))
	}
}

// 验证码固定长度
const captchaLength = 24

// 生成验证码（简化版）
func generateCaptcha() (string, error) {
	// 获取当前时间戳（精确到秒）
	now := time.Now().Unix()

	// 生成5字节随机数（10位十六进制）
	randBytes := make([]byte, 5)
	if _, err := rand.Read(randBytes); err != nil {
		return "", err
	}
	// 转换为无符号整数
	randNum := binary.BigEndian.Uint32(randBytes[:4])

	// 组合时间戳和随机数
	data := struct {
		Timestamp int64
		RandNum   uint32
	}{now, randNum}

	// 序列化为JSON
	dataBytes, err := json.Marshal(data)
	if err != nil {
		return "", err
	}

	// 计算简单校验和
	checksum := crc32.ChecksumIEEE(dataBytes) % 10000 // 4位校验和

	// 组合数据: 时间戳(10位) + 随机数(10位十六进制) + 校验和(4位) = 24位
	captchaStr := fmt.Sprintf("%010d%010x%04d", now, randNum, checksum)
	// 确保固定长度24位
	if len(captchaStr) > captchaLength {
		captchaStr = captchaStr[:captchaLength]
	}

	return captchaStr, nil
}

// 解析验证码（简化版）
func parseCaptcha(captcha string) (int64, error) {
	// 验证长度（必须为24位）
	if len(captcha) != 24 {
		return 0, fmt.Errorf("验证码长度错误")
	}

	// 分割各部分（10位时间戳 + 10位随机数 + 4位校验和）
	timestampStr := captcha[:10]
	randHex := captcha[10:20]
	checksumStr := captcha[20:24]

	// 解析时间戳
	timestamp, err := strconv.ParseInt(timestampStr, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("时间戳解析失败: %v", err)
	}

	// 解析随机数
	randNum, err := strconv.ParseUint(randHex, 16, 32)
	if err != nil {
		return 0, fmt.Errorf("随机数解析失败: %v", err)
	}

	// 解析校验和
	checksum, err := strconv.Atoi(checksumStr)
	if err != nil {
		return 0, fmt.Errorf("校验和解析失败: %v", err)
	}

	// 重新计算校验和验证
	data := struct {
		Timestamp int64
		RandNum   uint32
	}{timestamp, uint32(randNum)}

	dataBytes, err := json.Marshal(data)
	if err != nil {
		return 0, err
	}

	computedChecksum := int(crc32.ChecksumIEEE(dataBytes) % 10000)
	if computedChecksum != checksum {
		return 0, fmt.Errorf("验证码校验失败")
	}

	return timestamp, nil
}

// 验证时间是否在当前时间前后5分钟内
func validateTime(timestamp int64) bool {
	now := time.Now().Unix()
	diff := now - timestamp
	// 5分钟 = 300秒，允许前后5分钟
	return diff >= -300 && diff <= 300
}

// 处理主页请求，显示表单和生成验证码
func handleIndex(w http.ResponseWriter, r *http.Request) {
	// HTML模板
	html := `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>系统验证</title>
	<style>
		body { font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px; }
		.form-group { margin-bottom: 15px; }
		label { display: block; margin-bottom: 5px; }
		input { width: 100%; padding: 8px; box-sizing: border-box; }
		button { padding: 10px 15px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
		button:hover { background-color: #45a049; }
		.result { margin-top: 20px; padding: 10px; border-radius: 4px; }
		.success { background-color: #dff0d8; color: #3c763d; }
		.error { background-color: #f2dede; color: #a94442; }
	</style>
</head>
<body>
	<h1>系统验证</h1>
	<form action="/submit" method="post">
		<div class="form-group">
			<label for="systemName">系统名称:</label>
			<input type="text" id="systemName" name="systemName" required>
		</div>
		<div class="form-group">
			<label for="captcha">验证码:</label>
			<input type="text" id="captcha" name="captcha" required>
		</div>
		<button type="submit">提交</button>
	</form>
	{{if .Result}}
	<div class="result {{.ResultClass}}">{{.ResultMessage}}</div>
	{{end}}
</body>
</html>
	`

	// 解析并执行模板
	tmpl, err := template.New("index").Parse(html)
	if err != nil {
		http.Error(w, "解析模板失败: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// 传递数据到模板
	data := struct {
		Result        bool
		ResultClass   string
		ResultMessage string
	}{}

	tmpl.Execute(w, data)
}

// 处理表单提交
func handleSubmit(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	// 获取表单数据
	systemName := r.FormValue("systemName")
	captcha := r.FormValue("captcha")

	// 检查验证码是否已被使用
	if _, exists := usedCaptchas.Load(captcha); exists {
		showResult(w, false, "该验证码已被使用")
		return
	}

	// 解析验证码
	timestamp, err := parseCaptcha(captcha)
	if err != nil {
		showResult(w, false, fmt.Sprintf("验证码解析失败: %v", err))
		return
	}

	// 验证时间
	if !validateTime(timestamp) {
		showResult(w, false, "验证码已过期或无效，时间不在允许范围内")
		return
	}

	// 标记验证码为已用
	usedCaptchas.Store(captcha, struct{}{})

	// 验证成功
	// 添加到白名单
	_, err = db.Exec(fmt.Sprintf("INSERT INTO %s (%s, %s, %s) VALUES (?, ?, ?)", config.TableName, config.TypeFiled, config.ValueFiled, config.CodeFiled), config.TypeValue, systemName, captcha)
	if err != nil {
		showResult(w, false, fmt.Sprintf("验证成功，但添加到白名单失败: %v", err))
		return
	}
	showResult(w, true, fmt.Sprintf("验证成功！系统名称 '%s' 已添加到白名单", systemName))
}

// 显示验证结果
func showResult(w http.ResponseWriter, success bool, message string) {
	// 生成新的验证码（防止重复使用）
	newCaptcha, err := generateCaptcha()
	if err != nil {
		newCaptcha = "生成新验证码失败"
	}

	html := `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>系统验证结果</title>
	<style>
		body { font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px; }
		.form-group { margin-bottom: 15px; }
		label { display: block; margin-bottom: 5px; }
		input { width: 100%; padding: 8px; box-sizing: border-box; }
		button { padding: 10px 15px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
		button:hover { background-color: #45a049; }
		.result { margin-top: 20px; padding: 10px; border-radius: 4px; }
		.success { background-color: #dff0d8; color: #3c763d; }
		.error { background-color: #f2dede; color: #a94442; }
	</style>
</head>
<body>
	<h1>系统验证</h1>
	<form action="/submit" method="post">
		<div class="form-group">
			<label for="systemName">系统名称:</label>
			<input type="text" id="systemName" name="systemName" required>
		</div>
		<div class="form-group">
			<label for="captcha">验证码:</label>
			<input type="text" id="captcha" name="captcha" required>
			<p><small>当前验证码: ` + newCaptcha + `</small></p>
		</div>
		<button type="submit">提交</button>
	</form>
	<div class="result {{.ResultClass}}">{{.ResultMessage}}</div>
</body>
</html>
	`

	tmpl, err := template.New("result").Parse(html)
	if err != nil {
		http.Error(w, "解析模板失败: "+err.Error(), http.StatusInternalServerError)
		return
	}

	resultClass := "error"
	if success {
		resultClass = "success"
	}

	data := struct {
		ResultClass   string
		ResultMessage string
	}{
		ResultClass:   resultClass,
		ResultMessage: message,
	}

	tmpl.Execute(w, data)
}

func main() {
	// 注册路由
	http.HandleFunc("/", handleIndex)
	http.HandleFunc("/submit", handleSubmit)

	addr := fmt.Sprintf(":%d", config.ServerPort)
	fmt.Printf("服务器启动在 http://localhost%s\n", addr)
	err := http.ListenAndServe(addr, nil)
	if err != nil {
		fmt.Printf("服务器启动失败: %v\n", err)
	}
}
